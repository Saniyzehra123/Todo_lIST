import React from 'react'

const TodoList = ({data}) => {
  return (
    <div>
      
    </div>
  )
}

export default TodoList
